To run my code and replicate experiments in the write up:
1) Navigate to the folder titled Assignment1_Code
2) Run the script by entering the command:

sh runme.sh

3)Done
